/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIESREGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_serial_control.h
* Version      : 1.00
* Device(s)    : R5F5113xAxFP,R5F5231xAxFP,R5F51305AxFN
* Description  : This file includes the serial command.
***********************************************************************************************************************/

/***********************************************************************************************************************
* History      : DD.MM.YYYY Version    Description
*              : xx.xx.2015   1.00     First Release
***********************************************************************************************************************/

#ifndef	__R_SERIAL_CONTROL_H__	//[
#define	__R_SERIAL_CONTROL_H__
/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

#if (SELF_METHOD_NUM > 1)
#define MAX_SELF_SENSOR_ID   (SELF_ENABLE_NUM + SELF_DFNC_ENABLE_NUM)
#elif (SELF_METHOD_NUM > 0)
#define MAX_SELF_SENSOR_ID   (SELF_ENABLE_NUM)
#else
#define MAX_SELF_SENSOR_ID   (0)
#endif

#if (MUTUAL_METHOD_NUM > 7)
#define MAX_MUTUAL_SENSOR_ID   (MUTUAL0_NUM + MUTUAL1_NUM + MUTUAL2_NUM + MUTUAL3_NUM + \
                         MUTUAL4_NUM + MUTUAL5_NUM + MUTUAL6_NUM + MUTUAL7_NUM)
#elif (MUTUAL_METHOD_NUM > 6)
#define MAX_MUTUAL_SENSOR_ID   (MUTUAL0_NUM + MUTUAL1_NUM + MUTUAL2_NUM + MUTUAL3_NUM + \
                         MUTUAL4_NUM + MUTUAL5_NUM + MUTUAL6_NUM)
#elif (MUTUAL_METHOD_NUM > 5)
#define MAX_MUTUAL_SENSOR_ID   (MUTUAL0_NUM + MUTUAL1_NUM + MUTUAL2_NUM + MUTUAL3_NUM + MUTUAL4_NUM + MUTUAL5_NUM)
#elif (MUTUAL_METHOD_NUM > 4)
#define MAX_MUTUAL_SENSOR_ID   (MUTUAL0_NUM + MUTUAL1_NUM + MUTUAL2_NUM + MUTUAL3_NUM + MUTUAL4_NUM)
#elif (MUTUAL_METHOD_NUM > 3)
#define MAX_MUTUAL_SENSOR_ID   (MUTUAL0_NUM + MUTUAL1_NUM + MUTUAL2_NUM + MUTUAL3_NUM)
#elif (MUTUAL_METHOD_NUM > 2)
#define MAX_MUTUAL_SENSOR_ID   (MUTUAL0_NUM + MUTUAL1_NUM + MUTUAL2_NUM)
#elif (MUTUAL_METHOD_NUM > 1)
#define MAX_MUTUAL_SENSOR_ID   (MUTUAL0_NUM + MUTUAL1_NUM)
#elif (MUTUAL_METHOD_NUM > 0)
#define MAX_MUTUAL_SENSOR_ID   (MUTUAL0_NUM)
#else
#define MAX_MUTUAL_SENSOR_ID   (0)
#endif

#define MAX_SENSOR_ID   (MAX_SELF_SENSOR_ID + MAX_MUTUAL_SENSOR_ID)

#define HEAD_SIZE           (4)
#define MONITOR_CMD_SIZE    (40)

#define BUF_SIZE_SND_TMP    (HEAD_SIZE/* HEADER */ +                                                \
                             4/* BDATA */ * sizeof(uint16_t)/* WORD */ * METHOD_NUM +               \
                             2/* CV + RV */ * sizeof(uint16_t)/* WORD */ * MAX_SENSOR_ID +          \
                             1/* SLIDER POSITION */ * sizeof(uint16_t)/* WORD */ * SLIDER_NUMBER +  \
                             1/* WHEEL POSITION */ * sizeof(uint16_t)/* WORD */ * WHEEL_NUMBER +    \
                             1/* FLAGS */ * sizeof(uint16_t)/* WORD */ * METHOD_NUM +               \
                             /* CTVINTRP */sizeof(g_linear_interpolation_coefficient) +             \
                             /* CRVINTRP */sizeof(g_linear_interpolation_table) +                   \
                             2/* RETURN VALUE */)
                             
#define BUF_SIZE_SND_MTL    (2/* Primary + Secondary */ * sizeof(uint16_t)/* WORD */ * MAX_MUTUAL_SENSOR_ID)
#define BUF_SIZE_RCV        (HEAD_SIZE + MONITOR_CMD_SIZE)
#define BUF_SIZE_SND        ((BUF_SIZE_SND_TMP + BUF_SIZE_SND_TMP % 4) + BUF_SIZE_SND_MTL + BUF_SIZE_SND_MTL % 4)

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Exported global variables
***********************************************************************************************************************/

/***********************************************************************************************************************
Exported global functions (to be accessed by other files);
***********************************************************************************************************************/
void SerialCommandInitial(void);    // serial communication initialization
uint8_t SerialCommandReceive(uint8_t * value, uint16_t length);
uint8_t GetReplayMessage(uint8_t * value, uint16_t * length);
void PrepareReplayMessage(void);    // Replay message for IDE communication preparing
void TouchParamUpdate(void);
void StoreBurstMonitorMeasureValue(uint8_t method);
void BurstMonitorSendSensorValue(void);

#endif	//] __R_SERIAL_CONTROL_H__
