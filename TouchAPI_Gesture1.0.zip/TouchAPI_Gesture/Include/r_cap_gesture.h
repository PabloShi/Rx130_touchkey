/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_cap_gesture.h
* Description  : Interface file for gesture recognition.
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version Description
*         : 31.7.2018 1.00    First Release
***********************************************************************************************************************/

/**********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
**********************************************************************************************************************/
#ifndef R_CAP_GESTURE_H
#define R_CAP_GESTURE_H

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
#define CAPGST_SUCCESS         (0x00)      /* Success status of API */
#define CAPGST_ERROR           (0x01)      /* Error status of API */
#define CAPGST_REFRESH         (0x55)      /* Output refresh */

#define BUTTON_TIME            (49)        /* 20ms*(49+1) = 1s */
#define SWIPE_TIME             (3)         /* 20ms*(3+1) = 0.08s */
#define RELEASE_TIME           (3)         /* 20ms*(3+1) = 0.08s without input */
//#define DIRECTION              (0)         /* 0: Horizontal; 1: vertical */

/***********************************************************************************************************************
* Typedef definitions
***********************************************************************************************************************/

typedef enum
{
    GESTURE_RESULT_NONE,          /* No recognition result */
    GESTURE_RESULT_LEFT_UP_SWIPE,    /* Horizontal left swipe */
    GESTURE_RESULT_RIGHT_DOWN_SWIPE,   /* Horizontal right swipe */
    GESTURE_RESULT_LEFT_UP_ON,       /* LEFT sensor on */
    GESTURE_RESULT_RIGHT_DOWN_ON,      /* RIGHT sensor on */
    //GESTURE_RESULT_LEFT_LONG,       /* LEFT sensor on */
    //GESTURE_RESULT_RIGHT_LONG,      /* RIGHT sensor on */
    //GESTURE_RESULT_DOWN_SWIPE,    /* Vertical DOWN swipe */
    //GESTURE_RESULT_UP_SWIPE,      /* Vertical UP swipe */
    //GESTURE_RESULT_TOP_ON,        /* TOP sensor on */
    //GESTURE_RESULT_BOTTOM_ON,     /* BOTTOM sensor on */
} e_gesture_result_t;

typedef struct
{
    uint16_t    ratio_LR;                  /* (R-L)/(L+R)*100, diff value of L&R, for left or right judgment */
    uint16_t    ratio_thr;                 /* (R-L)/(THR)*100, diff value of L&R, for distance reference */
    uint8_t     cappos_signal_r;             /* "0": right<left; "1": right>left  */
    uint8_t     touch_input;
} st_cappos_input_t;

typedef enum
{
    STATUS_NONE_INPUT,            /* No position data input */
	STATUS_POSITION_FIRST_INPUT,  /* First touch position input */
    STATUS_LEFT_START,            /* Left start, judge button or right swipe */
    STATUS_RIGHT_START,           /* Right start, judge button or left swipe */
    STATUS_OUTPUT_RELEASE,        /* Gesture output hold time */
    //STATUS_LEFT_SW_RELEASE,         /* No recognition result */
    //STATUS_RIGHT_SW_RELEASE,        /* No recognition result */
    //STATUS_RIGHT_BT_RELEASE,        /* No recognition result */
    //STATUS_LEFT_BT_RELEASE,         /* No recognition result */
} e_gesture_status_t;

/***********************************************************************************************************************
* Exported global functions
***********************************************************************************************************************/
void R_GESTURE_Create(void);
uint16_t R_GESTURE_Detect(e_gesture_result_t * p_result, const st_cappos_input_t * p_cappos_input);

#endif /* R_CAP_GESTURE_H */
/***********************************************************************************************************************
* End of File
***********************************************************************************************************************/
