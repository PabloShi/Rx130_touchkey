/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2017(2018) Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_cap_position_if.h
* Description  : Interface file for position calc.
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version Description
*         : 31.7.2018 1.00    First Release
***********************************************************************************************************************/

/**********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
**********************************************************************************************************************/
#ifndef R_CAP_POSITION_H
#define R_CAP_POSITION_H

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* Conditioning parameters */
#define CAPPOS_CNF_MOVAVG_NUM    (15)      /* Number of Moving average */
#define CAPPOS_CNF_DRIFT_NUM     (15)      /* Number of Drift measure */

#define CAPPOS_SUCCESS          (0x00)      /* Success status of API */
#define CAPPOS_ERROR            (0x01)      /* Error status of API */
//#define CAPPOS_NODETECT         (0x3FFF)    /* Not detect position */

#define TOUCH_SENSITIVE         (1)         /* 0: Less and high anti-noise; 1: Middle and m anti-noise; 2: High and low anti-noise */
// for left or top electrode
#define TOUCH_LFT_THR           SELF_TS33_THR
// for right or bottom electrode
#define TOUCH_RGT_THR           SELF_TS07_THR
#if (TOUCH_SENSITIVE==0)
#define TOUCH_GS_THR            (((TOUCH_LFT_THR + TOUCH_RGT_THR) * 30) /2 / 100)
#elif(TOUCH_SENSITIVE==1)
#define TOUCH_GS_THR            (((TOUCH_LFT_THR + TOUCH_RGT_THR) * 20) /2 / 100)
#elif(TOUCH_SENSITIVE==2)
#define TOUCH_GS_THR            (((TOUCH_LFT_THR + TOUCH_RGT_THR) * 6) /2 / 100)
#endif

/***********************************************************************************************************************
* Typedef definitions
***********************************************************************************************************************/
typedef struct
{
    uint32_t sum;
    uint16_t dat[CAPPOS_CNF_MOVAVG_NUM];
    uint16_t ave;
    uint16_t ref;
    uint16_t  delta;
} st_cappos_data_t;

typedef enum
{
    CAPPOS_STATE_NONE,
    CAPPOS_STATE_INIT,
    CAPPOS_STATE_ACTIVE,
} e_cappos_states_t;

typedef struct
{
    uint16_t    ratio_LR;                  /* (R-L)/(L+R)*100, diff value of L&R, for left or right judgment */
    uint16_t    ratio_thr;                 /* (R-L)/(THR)*100, diff value of L&R, for distance reference */
    uint8_t     cappos_signal_r;           /* "0": right<left; "1": right>=left  */
    uint8_t     touch_input;
} st_cappos_result_t;

typedef struct
{
    uint16_t    rgt_dw_cnt;                        /* Count value of right electrode */
    uint16_t    lft_up_cnt;                        /* Count value of left electrode */
} st_captouch_data_t;

/***********************************************************************************************************************
* Exported global functions
***********************************************************************************************************************/
void R_CAPPOS_Create(void);
uint8_t R_CAPPOS_GetAve(st_captouch_data_t * captouch_data);
uint8_t R_CAPPOS_GetRef(st_captouch_data_t * captouch_data);
uint8_t R_CAPPOS_Read(st_cappos_result_t * pos_result, const st_captouch_data_t * captouch_data);

#endif /* R_CAP_POSITION_IF_H */
/***********************************************************************************************************************
* End of File
***********************************************************************************************************************/
