/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2017(2018) Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_cap_position.c
* Description  : This module Calculate posision.
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version Description
*         : 31.7.2018 1.00    First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes
***********************************************************************************************************************/
/* System include header */
#include <stdlib.h>
#include <stdint.h>

/* S/W include header */
#include "r_cap_gesture.h"
#include "r_cap_position.h"
#include "r_touch.h"

/***********************************************************************************************************************
* Private global variables and functions
***********************************************************************************************************************/
/* variables */
static e_gesture_status_t    gs_capgst_states;

/* functions */
void R_GESTURE_Create(void){
	gs_capgst_states = STATUS_NONE_INPUT;
}

//uint16_t buffer[400];
//uint16_t counter = 0;

uint16_t R_GESTURE_Detect(e_gesture_result_t * p_result, const st_cappos_input_t * p_cappos_input)
{
	static uint16_t timeout_counter = 0;         // counter for time out detect
	static uint8_t noinput_counter = 0;         // counter for no input detect
	static uint8_t button_counter = 0;		    // counter for button input counter
	static uint8_t valid_counter = 0;			// counter for input stable
	static uint8_t output_counter = 0;          // counter for output time release wait
	static uint16_t distance = 0;				// counter for distance of gesture movement
	uint16_t  status = CAPGST_ERROR;
	st_cappos_input_t previous_input;
	uint32_t calulate_temp = 0;

	status = CAPGST_ERROR;

	if (0 == p_cappos_input->touch_input)
	{
		if (gs_capgst_states != STATUS_OUTPUT_RELEASE)
		{
			// Time out reset
			noinput_counter ++;
			if  (noinput_counter > 3)
			{
				gs_capgst_states = STATUS_NONE_INPUT;
				*p_result = GESTURE_RESULT_NONE;
				noinput_counter = 0;
				valid_counter = 0;
				button_counter = 0;
				output_counter = 0;
				timeout_counter = 0;
			}
			//status = CAPGST_SUCCESS;
			return status;
		}
		else
		{
			// For output release
		}
	}
	else
	{
		noinput_counter = 0;
		if (gs_capgst_states == STATUS_NONE_INPUT)
		{
			gs_capgst_states = STATUS_POSITION_FIRST_INPUT;
		}
	}

	status = CAPGST_SUCCESS;
	switch (gs_capgst_states)
	{
		case STATUS_NONE_INPUT:
			// reset parameters
			previous_input.cappos_signal_r = 0;
			previous_input.ratio_LR = 0;
			previous_input.ratio_thr = 0;
			previous_input.touch_input = 0;
			button_counter = 0;
			valid_counter = 0;
			output_counter = 0;
			timeout_counter = 0;
			break;

		case STATUS_POSITION_FIRST_INPUT:
			if (p_cappos_input->cappos_signal_r)
			{
				gs_capgst_states = STATUS_RIGHT_START;
			}
			else
			{
				gs_capgst_states = STATUS_LEFT_START;
			}
			distance = 0;
			break;

		case STATUS_LEFT_START:
			if (p_cappos_input->cappos_signal_r == 0)
			{
				calulate_temp = ((p_cappos_input->ratio_thr * (TOUCH_GS_THR) * 100) / (TOUCH_LFT_THR)) ;
				// left half
#if (TOUCH_SENSITIVE==0)
				if ((p_cappos_input->ratio_LR >= 90) && (calulate_temp >= 400))
#elif(TOUCH_SENSITIVE==1)
				if ((p_cappos_input->ratio_LR >= 90) && (calulate_temp >= 300))
#elif(TOUCH_SENSITIVE==2)
				if ((p_cappos_input->ratio_LR >= 80) && (calulate_temp >= 200))
#endif
				//if ((p_cappos_input->ratio_LR >= 90) && (p_cappos_input->ratio_thr >= 300))
				{
					button_counter ++;
				}
				else if (previous_input.ratio_LR >= p_cappos_input->ratio_LR)
				{
					valid_counter ++;
					distance += previous_input.ratio_LR;
					distance -= p_cappos_input->ratio_LR;
				}
			}
			else if (p_cappos_input->cappos_signal_r == 1)
			{
				// right half
				if (previous_input.cappos_signal_r == 0)
				{
					valid_counter ++;
					distance += previous_input.ratio_LR;
					distance += p_cappos_input->ratio_LR;
				}
				else if (previous_input.ratio_LR <= p_cappos_input->ratio_LR)
				{
					valid_counter ++;
					distance += p_cappos_input->ratio_LR;
					distance -= previous_input.ratio_LR;
				}
			}

			if (button_counter > BUTTON_TIME)
			{
				// output left on
				button_counter = 0;
				*p_result = GESTURE_RESULT_LEFT_UP_ON;
				status = CAPGST_REFRESH;
				gs_capgst_states = STATUS_OUTPUT_RELEASE;
			}
#if (TOUCH_SENSITIVE==0)
			else if  ((valid_counter > SWIPE_TIME) && (distance > 60))
#elif(TOUCH_SENSITIVE==1)
			else if  ((valid_counter > SWIPE_TIME) && (distance > 50))
#elif(TOUCH_SENSITIVE==2)
			else if  ((valid_counter > (SWIPE_TIME-1)) && (distance > 40))
#endif
			{
				// output right swipe
				valid_counter = 0;
				*p_result = GESTURE_RESULT_RIGHT_DOWN_SWIPE;
				status = CAPGST_REFRESH;
				gs_capgst_states = STATUS_OUTPUT_RELEASE;
			}
			timeout_counter = 0;
			break;

		case STATUS_RIGHT_START:
			if (p_cappos_input->cappos_signal_r == 1)
			{
				// right half
				calulate_temp = ((p_cappos_input->ratio_thr * (TOUCH_GS_THR) * 100) / (TOUCH_RGT_THR)) ;
#if (TOUCH_SENSITIVE==0)
				if ((p_cappos_input->ratio_LR >= 90) && (calulate_temp >= 400))
#elif(TOUCH_SENSITIVE==1)
				if ((p_cappos_input->ratio_LR >= 90) && (calulate_temp >= 300))
#elif(TOUCH_SENSITIVE==2)
				if ((p_cappos_input->ratio_LR >= 80) && (calulate_temp >= 200))
#endif
				{
					button_counter ++;
				}
				else if (previous_input.ratio_LR >= p_cappos_input->ratio_LR)
				{
					valid_counter ++;
					distance += previous_input.ratio_LR;
					distance -= p_cappos_input->ratio_LR;
				}
			}
			else if (p_cappos_input->cappos_signal_r == 0)
			{
				// left half
				if (previous_input.cappos_signal_r == 0)
				{
					valid_counter ++;
					distance += previous_input.ratio_LR;
					distance += p_cappos_input->ratio_LR;
				}
				else if (previous_input.ratio_LR <= p_cappos_input->ratio_LR)
				{
					valid_counter ++;
					distance += p_cappos_input->ratio_LR;
					distance -= previous_input.ratio_LR;
				}
			}

			if (button_counter > BUTTON_TIME)
			{
				// output left on
				button_counter = 0;
				*p_result = GESTURE_RESULT_RIGHT_DOWN_ON;
				status = CAPGST_REFRESH;
				gs_capgst_states = STATUS_OUTPUT_RELEASE;
			}
#if (TOUCH_SENSITIVE==0)
			else if  ((valid_counter > SWIPE_TIME) && (distance > 60))
#elif(TOUCH_SENSITIVE==1)
			else if  ((valid_counter > SWIPE_TIME) && (distance > 50))
#elif(TOUCH_SENSITIVE==2)
			else if  ((valid_counter > (SWIPE_TIME-1)) && (distance > 40))
#endif
			{
				// output right swipe
				valid_counter = 0;
				*p_result = GESTURE_RESULT_LEFT_UP_SWIPE;
				status = CAPGST_REFRESH;
				gs_capgst_states = STATUS_OUTPUT_RELEASE;
			}
			timeout_counter = 0;
			break;

		case STATUS_OUTPUT_RELEASE:
			timeout_counter ++;
			if ((0 == p_cappos_input->touch_input) ||  (timeout_counter > 600))
			{
				output_counter ++;
				if (output_counter > RELEASE_TIME)
				{
					gs_capgst_states = STATUS_NONE_INPUT;
					*p_result = GESTURE_RESULT_NONE;
					noinput_counter = 0;
					valid_counter = 0;
					button_counter = 0;
					output_counter = 0;
					timeout_counter = 0;
				}
			}
			break;

		default:
			// Dummy
			break;
	}
/*
 	previous_input.cappos_signal_r = p_cappos_input->cappos_signal_r;
	previous_input.ratio_LR = p_cappos_input->ratio_LR;
	previous_input.ratio_thr = p_cappos_input->ratio_thr;
	previous_input.touch_input = p_cappos_input->touch_input;


	buffer[counter] = p_cappos_input->ratio_LR;
	counter++;
	buffer[counter] = p_cappos_input->ratio_thr;
	counter++;
	buffer[counter] = p_cappos_input->cappos_signal_r;
	counter++;
	buffer[counter] = p_cappos_input->touch_input;
	counter++;
	if (counter>=400){
		counter = 0;
	}
*/

    return status;
}
/***********************************************************************************************************************
* End of File
***********************************************************************************************************************/
