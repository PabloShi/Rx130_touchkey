/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2017(2018) Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_cap_position.c
* Description  : This module Calculate posision.
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version Description
*         : 31.7.2018 1.00    First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes
***********************************************************************************************************************/
/* System include header */
#include <stdlib.h>
#include <stdint.h>
#include "r_touch.h"

/* S/W include header */
#include "r_cap_position.h"

/***********************************************************************************************************************
* Private global variables and functions
***********************************************************************************************************************/
/* variables */
static e_cappos_states_t    gs_cappos_states;
static st_cappos_data_t     gs_rgt;
static st_cappos_data_t     gs_lft;
static uint16_t             gs_count_movavg;
static uint16_t             gs_count_drift;

//int16_t buffer[400];
//uint16_t counter = 0;

/* functions */
static void    calc_position(st_cappos_result_t * p_cappos_result, const st_captouch_data_t * p_captouch_data);

/***********************************************************************************************************************
* Function Name: R_CAPPOS_Create
* Description  : Create cap position data
* Arguments    : None
* Return Value : uint8_t status    : CAPPOS_SUCCESS or CAPPOS_ERROR
***********************************************************************************************************************/
//uint8_t R_CAPPOS_Create(void)
void R_CAPPOS_Create(void)
{
	//uint8_t  status = CAPPOS_ERROR;

	/* Initialize variables */
	gs_count_movavg = 0;
	gs_count_drift = 0;
	gs_rgt.sum = 0;
	gs_lft.sum = 0;

    /* Change state  */
    gs_cappos_states = CAPPOS_STATE_INIT;

    //status = CAPPOS_SUCCESS;
    
    //return status;
}   /* eof R_CAPPOS_Create() */

/***********************************************************************************************************************
* Function Name: R_CAPPOS_Read
* Description  : Get result of cap position data
* Arguments    : st_cappos_result_t * p_cappos_result  : position result pointer
*              : st_captouch_data_t * p_captouch_data : cap touch data pointer
* Return Value : uint8_t status    : CAPPOS_SUCCESS or CAPPOS_ERROR
***********************************************************************************************************************/
uint8_t R_CAPPOS_Read(st_cappos_result_t * p_cappos_result, const st_captouch_data_t * p_captouch_data)
{
    uint8_t  status = CAPPOS_ERROR;
    float    delta_ave;

	p_cappos_result->touch_input = 0;

    /* Check created calculate base */
    if (CAPPOS_STATE_NONE == gs_cappos_states)
    {
        return status;
    }

	/* Moving average */
	if (CAPPOS_STATE_ACTIVE <= gs_cappos_states)
	{
		/* Delete the oldest data */
		gs_rgt.sum -= gs_rgt.dat[gs_count_movavg];
		gs_lft.sum -= gs_lft.dat[gs_count_movavg];
	}

	/* Store new data */
	gs_rgt.dat[gs_count_movavg] = p_captouch_data->rgt_dw_cnt;
	gs_lft.dat[gs_count_movavg] = p_captouch_data->lft_up_cnt;

	/* Add new data */
	gs_rgt.sum += gs_rgt.dat[gs_count_movavg];
	gs_lft.sum += gs_lft.dat[gs_count_movavg];


    if (CAPPOS_STATE_ACTIVE <= gs_cappos_states)
    {
        /* Calculate moving average */
        gs_rgt.ave = gs_rgt.sum / CAPPOS_CNF_MOVAVG_NUM;
        gs_lft.ave = gs_lft.sum / CAPPOS_CNF_MOVAVG_NUM;
    }
    else
    {
        /* Data was collected */
        if ((CAPPOS_CNF_MOVAVG_NUM - 1) <= gs_count_movavg)
        {
            /* Calculate moving average */
            gs_rgt.ave = gs_rgt.sum / CAPPOS_CNF_MOVAVG_NUM;
            gs_lft.ave = gs_lft.sum / CAPPOS_CNF_MOVAVG_NUM;

            /* Set reference data */
            gs_rgt.ref = gs_rgt.ave;
            gs_lft.ref = gs_lft.ave;
            /* Change gs_cappos_states */
            gs_cappos_states = CAPPOS_STATE_ACTIVE;
        }
    }

    gs_count_movavg++;
    /* Reset counter */
    if (CAPPOS_CNF_MOVAVG_NUM <= gs_count_movavg)
    {
        gs_count_movavg = 0;
    }

    if (CAPPOS_STATE_ACTIVE <= gs_cappos_states)
    {
        /* Calculate delta */
        //gs_rgt.delta = gs_rgt.ave - gs_rgt.ref;
        //gs_lft.delta = gs_lft.ave - gs_lft.ref;
    	// electrode correction added
    	if (p_captouch_data->rgt_dw_cnt >= gs_rgt.ref)
    	{
    		delta_ave = (p_captouch_data->rgt_dw_cnt - gs_rgt.ref) * (TOUCH_LFT_THR + TOUCH_RGT_THR) / TOUCH_RGT_THR;
			gs_rgt.delta = (uint16_t) delta_ave;
    	}
    	else
    	{
    		gs_rgt.delta = 0;
    	}
    	if (p_captouch_data->lft_up_cnt >= gs_lft.ref)
    	{
    		delta_ave = (p_captouch_data->lft_up_cnt - gs_lft.ref) * (TOUCH_LFT_THR + TOUCH_RGT_THR) / TOUCH_RGT_THR;
			gs_lft.delta =  (uint16_t) delta_ave;
    	}
    	else
    	{
    		gs_lft.delta = 0;
    	}

        /* Calculate average of four delta */
        delta_ave = (float)(gs_rgt.delta + gs_lft.delta) / 2;

        /* Check detect hand is closing to sensor and cappos_states  */
        if (TOUCH_GS_THR > delta_ave)
        {
            // clear cappos parameters
            p_cappos_result->ratio_thr = 0;
            p_cappos_result->ratio_LR = 0;
            p_cappos_result->touch_input = 0;
    		p_cappos_result->cappos_signal_r = 0;

            gs_count_drift ++;
            if (CAPPOS_CNF_DRIFT_NUM <= gs_count_drift)
            {
            	gs_count_drift = 0;

				// Update reference data (Only when not-touch input set)
            	gs_rgt.ref = gs_rgt.ave;
				gs_lft.ref = gs_lft.ave;
            }
        }
        else
        {
            p_cappos_result->touch_input = 1;

            /* Calculate position */
            calc_position(p_cappos_result, p_captouch_data);
            // Clear drift counter when gesture touch input
            gs_count_drift = 0;
        }
    }

	status = CAPPOS_SUCCESS;

    return status;
}   /* eof R_CAPPOS_Read() */

/***********************************************************************************************************************
* Function Name: R_CAPPOS_GetAve
* Description  : Get count average
* Arguments    : st_captouch_data_t * p_captouch_data : cap touch data pointer
* Return Value : uint8_t status    : CAPPOS_SUCCESS or CAPPOS_ERROR
***********************************************************************************************************************/
uint8_t R_CAPPOS_GetAve(st_captouch_data_t * p_captouch_data)
{
    uint8_t  status = CAPPOS_ERROR;

    if (NULL == p_captouch_data)
    {
        return status;
    }

    p_captouch_data->rgt_dw_cnt = gs_rgt.ave;
    p_captouch_data->lft_up_cnt = gs_lft.ave;

    status = CAPPOS_SUCCESS;

    return status;
}   /* eof R_CAPPOS_GetAve() */

/***********************************************************************************************************************
* Function Name: R_CAPPOS_GetRef
* Description  : Get count reference
* Arguments    : st_captouch_data_t * p_captouch_data : cap touch data pointer
* Return Value : uint8_t status    : CAPPOS_SUCCESS or CAPPOS_ERROR
***********************************************************************************************************************/
uint8_t R_CAPPOS_GetRef(st_captouch_data_t * p_captouch_data)
{
    uint8_t  status = CAPPOS_ERROR;

    if (NULL == p_captouch_data)
    {
        return status;
    }

    p_captouch_data->rgt_dw_cnt = gs_rgt.ref;
    p_captouch_data->lft_up_cnt = gs_lft.ref;

    status = CAPPOS_SUCCESS;

    return status;
}   /* eof R_CAPPOS_GetRef() */

/***********************************************************************************************************************
* Function Name: calc_position
* Description  : Calculate position
* Arguments    : st_cappos_result_t * p_cappos_result  : position result pointer
*                float delta_ave : delta average value of four electrodes
* Return Value : None
***********************************************************************************************************************/
static void calc_position(st_cappos_result_t * p_cappos_result, const st_captouch_data_t * p_captouch_data)
{
	//uint16_t lft_diff;
	//int16_t rgt_diff;
	float work_x1;
	float work_x2;

	if (gs_rgt.delta >= gs_lft.delta){
		work_x1 = (gs_rgt.delta - gs_lft.delta) * 100 / TOUCH_GS_THR;
		work_x2 = (gs_rgt.delta - gs_lft.delta) * 100 / (gs_rgt.delta + gs_lft.delta);
		p_cappos_result->cappos_signal_r = 1;
	}
	else
	{
		work_x1 = (gs_lft.delta - gs_rgt.delta) * 100 / TOUCH_GS_THR;
		work_x2 = (gs_lft.delta - gs_rgt.delta) * 100 / (gs_rgt.delta + gs_lft.delta);
		p_cappos_result->cappos_signal_r = 0;
	}

    p_cappos_result->ratio_thr = (uint16_t) work_x1;
    p_cappos_result->ratio_LR = (uint16_t) work_x2;


    /*
	buffer[counter] = p_captouch_data->rgt_cnt;
	counter++;
	buffer[counter] = p_captouch_data->lft_cnt;
	counter++;
	buffer[counter] = gs_rgt.ref;
	counter++;
	buffer[counter] = gs_lft.ref;
	counter++;
	buffer[counter] = p_cappos_result->ratio_LR;
	counter++;
	buffer[counter] = p_cappos_result->ratio_thr;
	counter++;
	buffer[counter] = p_cappos_result->cappos_signal_r;
	counter++;
	buffer[counter] = p_cappos_result->touch_input;
	counter++;
	if (counter>=400){
		counter = 0;
	}
    */

}   /* eof calc_position() */

/***********************************************************************************************************************
* End of File
***********************************************************************************************************************/

